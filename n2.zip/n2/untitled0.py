#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 11:32:42 2022

@author: dannaluna
"""

def avanzar_semestre(estudiante1: dict, estudiante2: dict, estudiante3: dict, estudiante4: dict)-> None:
    
    estudiante1["ssc"] += 1
    estudiante2["ssc"] += 1
    estudiante3["ssc"] += 1
    estudiante4["ssc"] += 1 
    

def contar_genero(estudiante1: dict, estudiante2: dict, estudiante3: dict, estudiante4: dict)-> dict:
    
    masculino=0
    femenino=0
    
    if estudiante1["género"] == "masculino":
        masculino += 1
    else:
        femenino += 1
    
    if estudiante2["género"] == "masculino":
        masculino += 1 
    else:
        femenino += 1
    
    if estudiante3["género"] == "masculino":
        masculino += 1
    else:
        femenino += 1
    
    if estudiante4["género"] == "masculino": 
        masculino += 1
    else:
        femenino += 1
    
    
    dic_final = {"hombres":masculino, "mujeres":femenino}
    return dic_final


def contar_por_anio_ingreso(estudiante1: dict, estudiante2: dict, estudiante3: dict, estudiante4: dict, anio_ingreso: int)-> dict:
    
    anio_1 = (int(estudiante1["código"])) // 100000
    anio_2 = (int(estudiante1["código"])) // 100000
    anio_3 = (int(estudiante1["código"])) // 100000
    anio_4 = (int(estudiante1["código"])) // 100000
    
    anio = 0
    
    if anio_ingreso == anio_1:
        anio += 1
    
    if anio_ingreso == anio_2:
        anio += 1
    
    if anio_ingreso == anio_3:
        anio += 1
    
    if anio_ingreso == anio_4:
        anio += 1
    
    dic_final = {anio_ingreso:anio}
    return dic_final
    dic_final = {anio_1:anio, anio_2:anio, anio_3:anio, anio_4:anio}
    return dic_final


    
    
    
    
    
    
    